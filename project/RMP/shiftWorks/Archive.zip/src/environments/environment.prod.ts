/**
 * Export production environment
 */

export const environment = {
    apiRoot: '/our/api/root',
    production: true
};
