import { RealDatePipe } from './real-date.pipe';

describe('RealDatePipe', () => {
  it('create an instance', () => {
    const pipe = new RealDatePipe();
    expect(pipe).toBeTruthy();
  });
});
