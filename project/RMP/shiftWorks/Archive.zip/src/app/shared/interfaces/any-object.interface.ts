/**
 * Export interface IAnyObject
 */

export interface IAnyObject {
  [key: string]: any;
}
