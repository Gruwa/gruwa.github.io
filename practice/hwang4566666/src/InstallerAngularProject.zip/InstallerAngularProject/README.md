[![Signal Design System Version 2](img/logo.png)](https://bla-bla.com "Title")

# Installer for new Angular project with Signal Design System Version 2

This package help install the latest version of Angular project with Signal Design System Version 2

### Quick start

**Make sure you have Node version >= 12.16.1 and (NPM >= 6.13.4 or [Yarn](https://yarnpkg.com) )**

> Install project from NPM

```bash
# get the project from npm
npm install @signal2/installer-signal2-proj

# create new project
npx signal2-project

# change directory to your project
cd your-project

# start working with your project
```

# Table of Contents

* [File Structure](#file-structure)
* [Getting Started](#getting-started)
    * [Global dependencies](#global-dependencies)
    * [Project dependencies](#project-dependencies)
    * [Development dependencies](#development-dependencies)
    * [Installing](#installing)
    * [Using the new project](#using-the-new-project)
* [Test suite](#test-suite)
    * [General cases](#general-cases)
    * [Starting testing process](#starting-testing-process)
* [License](#license)

## File Structure

```
install-signal2-proj/
│
├──img/                           * images
│   └──logo.png                   * logo file
├──clean-test-data.js             * script for clean data after test use
├──extra-methods.js               * methods what used for installing process
├──extra-methods.test.js          * test cases for methods
├──jet.config.js                  * config file of jet
├──signal2-project.js             * config that will be used for installing a new project
├──LICENSE                        * license file
├──package.json                   * what npm uses to manage its dependencies
└──README.md                      * readme file

```

# Getting Started

## Global dependencies

What you need to run this package:

* `node` and `npm` (`brew install node`)
* Ensure you're running the latest versions Node `v12.x.x`+ and NPM `6.x.x`+

> If you have `nvm` installed, which is highly recommended (`brew install nvm`) you can do a `nvm install --lts && nvm use` in `$` to run with the latest Node LTS. You can also have this `zsh` done for you [automatically](https://github.com/creationix/nvm#calling-nvm-use-automatically-in-a-directory-with-a-nvmrc-file)

## Project dependencies

* `prompt`version >= 1.1.0

## Development dependencies

* `jest`version >= 26.6.3

## Installing

* `npm install @signal2/installer-signal2-proj` install NPM package
* `npm install` to install all dependencies or `yarn`
* `npx signal2-project` to install the latest version Angular project with Signal Design System Version 2

## Using the new project

After you have installed new project use `cd your-project` for starting work with your new project

# Test suite

## General cases

General cases you can find in `extra-methods.test.js`.

## Starting testing process

For start testing use `npm run test-flow`.

# License

[LICENSE](/LICENSE)
