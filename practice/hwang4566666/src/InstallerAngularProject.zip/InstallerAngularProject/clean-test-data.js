const rimraf = require('rimraf');

/**
 * Delete all data what was created
 */
((projectName = 'test-project') => {
    rimraf(`${projectName}`, function () {
    });
    rimraf('node_modules', function () {
    });
    rimraf('package-lock.json', function () {
    });
})();

