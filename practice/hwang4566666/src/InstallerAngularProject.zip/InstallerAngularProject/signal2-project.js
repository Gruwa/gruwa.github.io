#!/usr/bin/env node
const extraMethods = require('./extra-methods');

/**
 * This script prepare for working from NPM package.
 *
 * Script include logic for creating new Angular project.
 *
 * Angular project will have latest version.
 * Angular project will include shared library of Signal2
 *
 * At the end script will delete old folders and files.
 */

((
    execSync = require('child_process').execSync,
    prompt = require('prompt'),
    os = process.platform,
) => {
    console.log('Welcome!');

    prompt.start();
    prompt.get(['Please enter name of project'], (err, result) => {
        /**
         * Project name of a new Angular project with shared library
         */
        const projectName = result['Please enter name of project'];

        /**
         * Installing Angular CLI
         */
        extraMethods.installAngularCli(execSync);

        /**
         * Installing new Angular project
         */
        extraMethods.installAngularProject(execSync, projectName);

        /**
         * Installing shared library
         */
        extraMethods.installSharedLibrary(execSync, projectName);

        /**
         * Deleting old files
         */
        extraMethods.deleteInstallationFiles(execSync, os);

        /**
         * Welcome message
         */
        extraMethods.welcomeMessage(projectName);
    });
})();
