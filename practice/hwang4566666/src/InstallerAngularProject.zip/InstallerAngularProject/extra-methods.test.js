const extraMethods = require('./extra-methods');
const projectName = 'test-project';
const execSync = require('child_process').execSync;

test('Test of installing Angular CLI', () => {
    let result = extraMethods.installAngularCli(execSync);

    expect(result).toContain('@angular/cli');
});

test('Test of installing new Angular project', () => {
    let result = extraMethods.installAngularProject(execSync, projectName);

    expect(result).toContain(projectName);
});

test('Test of installing Shared library', () => {
    let result = extraMethods.installSharedLibrary(execSync, projectName);

    expect(result).toContain('@gruwa/shared-library'); //TODO change name of project
});

test('Test of welcome message', () => {
    let result = extraMethods.welcomeMessage(projectName);

    expect(result).toEqual(`Welcome to the ${projectName.toUpperCase()} project!`);
});
