const rimraf = require('rimraf');

/**
 * Local installing Angular CLI NPM package
 * @param execSync
 * @returns string
 */
const installAngularCli = (execSync) => {
    console.info('Installing Angular CLI...');

    return execSync(`npm install @angular/cli`).toString();
}

/**
 * Installing new project with last version of Angular
 * @param execSync
 * @param projectName - name for new project
 * @returns string
 */
const installAngularProject = (execSync, projectName) => {
    console.info('Installing new Angular project...');

    return execSync(`ng new ${projectName} --style=scss --routing=true`).toString();
}

/**
 * Installing shared library in the new project
 * @param execSync
 * @param projectName - name for new project for opening folder with project
 * @returns string
 */
const installSharedLibrary = (execSync, projectName) => {
    console.info('Installing shared library...');

    return execSync(`npm i @gruwa/shared-library --prefix ${projectName}`).toString(); // TODO Change name of shared library
}

/**
 * Delete old folder and files what remained in the folder
 * @param execSync
 * @param os - work OS of work station
 * @returns {{nodeModules, packageLock}}
 */
const deleteInstallationFiles = (execSync, os) => {
    console.info('Deleting old files...');

    rimraf('node_modules', function () {
    });
    rimraf('package-lock.json', function () {
    });
}

/**
 * Welcome message after finishing all processes
 * @param projectName - name of new project
 */
const welcomeMessage = (projectName) => {
    const message = `Welcome to the ${projectName.toUpperCase()} project!`;

    console.info(message);

    return message;
}

exports.installAngularCli = installAngularCli;
exports.installAngularProject = installAngularProject;
exports.installSharedLibrary = installSharedLibrary;
exports.deleteInstallationFiles = deleteInstallationFiles;
exports.welcomeMessage = welcomeMessage;
